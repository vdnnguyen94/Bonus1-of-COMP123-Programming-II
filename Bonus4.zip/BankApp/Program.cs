﻿using System;

namespace BankApp
{
    class Program
    {
        static void Main(string[] args)
        {
            BankAccount MyAccount = new BankAccount(545618, "Van Nguyen", 87.25);
            Console.WriteLine(MyAccount.ToString());
            Console.Write("Please enter deposit amount: ");
            double amount = Convert.ToDouble(Console.ReadLine());
            MyAccount.Deposit(amount);
            Console.WriteLine(MyAccount.ToString());

            Console.Write("Please enter withdrawl amount: ");
            amount = Convert.ToDouble(Console.ReadLine());
            MyAccount.Wihtdraw(amount);
            Console.WriteLine(MyAccount.ToString());

        }
    }
}
