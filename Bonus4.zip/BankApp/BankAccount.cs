﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankApp
{
    public class BankAccount
    {
        private double balance;
        public int AccountNumber;
        public string CustomerName;
        public double Balance
        {
            get { return balance; }
        }
        public BankAccount(int accountnumber, string cusname, double balance)
        {
            AccountNumber = accountnumber;
            CustomerName = cusname;
            this.balance = balance;
        }
        public void Wihtdraw(double amount)
        {
            if (amount <= 0)
            {
                throw new ArgumentOutOfRangeException("Amount cannot be 0 nor negative");
            } else if (amount > balance)
            {
                throw new ArgumentOutOfRangeException("Amount cannot be greater than the Balance");
            }
            else { balance = balance - amount; }
            
        }
        public void Deposit(double amount)
        {
            if (amount <= 0)
            {
                throw new ArgumentOutOfRangeException("Amount cannot be 0 nor negative");
            }
            else { balance = balance + amount; }

        }
        public override string ToString()
        {
            return $"Owner of {AccountNumber} account is {CustomerName}. The balance is ${Balance}.";
        }
    }
}
