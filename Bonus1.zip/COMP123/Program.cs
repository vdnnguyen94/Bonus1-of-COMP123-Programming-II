﻿using System;

namespace COMP123
{
    class Program
    {
        public static void printme()
        {
            Console.WriteLine("print me");
        }
        public static void CalculateCommission()
        {
            Console.Write("Enter your sales amount: ");
            double amount = Convert.ToDouble(Console.ReadLine());
            double commission = (amount > 1000) ? (amount - 1000) * 0.25 : 0;
            Console.WriteLine($"For sales of {amount:c} your commission is {commission:c}");
        }

        static void Main(string[] args)
        {
            // Syntax for "simple" types:
            string text = "This is a text";
            int[] numbers = new int[5];
            CalculateCommission();
            // Syntax for classes:
            printme();

        }
    }
}
