using Microsoft.VisualStudio.TestTools.UnitTesting;
using BankApp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace BankTests
{
    [TestClass]
    public class BankAppTests
    {
        [TestMethod]
        public void Deposit_ValidAmount_UpdatesBalance()
        {
            //arange
            double expectedbalance = 50.1;
            //act 
            BankAccount myaccount = new BankAccount(123456789, "ABC DEF", 0.1);
            myaccount.Deposit(50);
            //Assert
            Assert.AreEqual(expectedbalance, myaccount.Balance);
        }
        [TestMethod]
        public void Withdraw_ValidAmount_UpdatesBalance()
        {
            //arange
            double expectedbalance = 25;
            //act 
            BankAccount myaccount = new BankAccount(123456789, "ABC DEF", 0.1);
            myaccount.Deposit(50);
            myaccount.Wihtdraw(25.1);
            //Assert
            Assert.AreEqual(expectedbalance, myaccount.Balance);
        }
        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Withdraw_Greater_Than_Balance()
        {
            //arange
            BankAccount myaccount = new BankAccount(123456789, "ABC DEF", 0.1);

            //act//assert
            myaccount.Wihtdraw(5);
            
        }
        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Withdraw_Equalorlessthan_Zero()
        {
            BankAccount myaccount = new BankAccount(123456789, "ABC DEF", 0.1);
            myaccount.Wihtdraw(-5);

        }
        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Deposit_Equalorlessthan_Zero()
        {
            BankAccount myaccount = new BankAccount(123456789, "ABC DEF", 0.1);
            myaccount.Deposit(-5);

        }
       }
}
