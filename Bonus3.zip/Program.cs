﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.IO;
namespace Bonus3
{
    class Program
    {
        static void Main(string[] args)
        {
            //301289600 VAN NGUYEN
            List<InvalidLine> InvalidLines = new List<InvalidLine>();
            List<double> NumbersList = new List<double>();
            Console.WriteLine("Please Enter The File Name containing the list of numbers: ");
            string FileName = Console.ReadLine();
            int ReadingLine = 1;
            int Errors = 0;
            StreamReader reader = null;
            string line = null;
            try
            {
                reader = new StreamReader(FileName);
                line = reader.ReadLine();
                //checking if the first line is empty
                if (line == null)
                {
                    Console.WriteLine("FILE is Valid, BUT FILE IS EMPTY");

                    throw new Exception("EMPTY FILE");
                }
                //If First Line is not NULL, READING Continues
                while (line != null)
                {
                    double Number = Convert.ToDouble(line);
                    NumbersList.Add(Number);
                    ReadingLine++;
                    line = reader.ReadLine();
                }
            }
            catch (FileNotFoundException Error)
            {
                Console.WriteLine(Error.Message);
            }
            catch (InvalidDataException Error)
            {
                InvalidLines.Add(new InvalidLine(ReadingLine, line));
                Errors = 1;
                Console.WriteLine($"{ReadingLine}: {Error.Message}");
            }
            catch (Exception Error)
            {
                Console.WriteLine(Error.Message);
            }
            finally
            {
                reader.Close();
            }

            double Total = 0;
            double Avg = 0;
            if (NumbersList.Count > 0)
            {
                foreach (double number in NumbersList)
                {
                    Total = Total + number;
                }
                Avg = Total / NumbersList.Count;
                Console.WriteLine($"There are {NumbersList.Count} valid Numbers from the {FileName}");
                Console.WriteLine($"Average of all numbers from the lis is: {Avg}");

            }
            if (Errors > 0)
            {
                Console.WriteLine($"\n\n There are {InvalidLines.Count} Errors from the File");
                foreach (InvalidLine wrongline in InvalidLines)
                {
                    Console.WriteLine(wrongline);
                }

            }

        }
        public class InvalidLine
        {
            public int LineNumber { get; set; }
            public string LineValue { get; set; }
            public InvalidLine(int num, string value)
            {
                LineNumber = num;
                LineValue = value;
            }
            public override string ToString()
            {
                return $"{LineNumber}: {LineValue}";
            }
        }
    }
}
